package task11_1;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class LinearEq {
	private static final double EPSILON = 1e-10;
	double[][] aug_matrix;
	double[][] all_matrix;
	
	LinearEq(String file){
		//args = 0
		all_matrix = readFromFile(file);
	}
	
	public double[][] readFromFile(String file){
		int rows = 0;
		int columns = 0;
		ArrayList<ArrayList<Double>> data = new ArrayList<ArrayList<Double>>();
		try { 
			Scanner input = new Scanner (new File(file));
			for(rows =0; input.hasNextLine(); rows++) {
				String nextLine = input.nextLine();
				if(nextLine.isEmpty()) {
					break;
				}
				else {		
					Scanner colReader = new Scanner(nextLine);
					ArrayList<Double> col = new ArrayList<Double>();
					for (columns = 0; colReader.hasNextDouble(); columns++) {
						//System.out.println(colReader.nextDouble());
						col.add(colReader.nextDouble());
					}
					data.add(col);
					//System.out.println(data);
					colReader.close();
				}
			}
			input.close();
		} catch (IOException e) {
			System.out.println(e);
			//System.exit(1);
		}
		
		//2 double[][]
		double a[][] = new double[rows][columns];
		try {
			Scanner input = new Scanner(new File(file));
			for(int i = 0; i < rows; ++i) {
				for(int j = 0; j < columns; ++j) {
					if(input.hasNextDouble()) {
						a[i][j] = input.nextDouble();
					}
				}
			}
			input.close();
		} catch (IOException e) {
			System.out.println(e);
			System.exit(1);
		}
		return(a);
	}
	
	// connect to Vector
	public Vector A() {
		//returns the coefficient matrix
		int rows = all_matrix.length;
		int columns =  all_matrix[0].length;
		double[][] coeffi = new double[rows-1][columns];
		//System.out.println(all_matrix[rows][0]);
		for(int i = 0; i < rows-1; i++) {
			for(int j =0; j < columns; j++) {
				coeffi[i][j] = all_matrix[i][j];
			}
		}
		//System.out.println(coeffi[3][2]);
		//Vector a = new Vector(coeffi);
		Vector A = new Vector(coeffi);
		return A;
	}
	
	// connect to Vector
	public Vector b() {
		// return the constant vector
		int rows = all_matrix.length;
		int columns =  all_matrix[0].length;
		double[] constV = new double[columns];
		//System.out.println(all_matrix[rows][0]);
		for(int i = 0; i < columns; i++) {
			//System.out.println(all_matrix[rows-1][i]);
			constV[i] = all_matrix[rows-1][i];
			//System.out.println(constV[i]);
		}
		//System.out.println(constV[0][3]);
		Vector b = new Vector(constV);
		return b;
	}
	
	public Vector aug_matrix() {
		// return the constant vector
		int rows = all_matrix.length;
		int columns =  all_matrix[0].length;
		double[][] aug_matrix = new double[rows -1][columns + 1];
		//System.out.println(all_matrix[rows-1][3]); // last
		for(int i = 0; i < rows-1; i++) {
			for(int j =0; j < columns + 1; j++) {
				if(j == columns) {
				//	System.out.println(j); // last
					aug_matrix[i][j] = all_matrix[rows-1][i];
				}
				else
					aug_matrix[i][j] = all_matrix[i][j];
			}
		}
		//System.out.println(aug_matrix[1][4]); // last
		//System.out.println(all_matrix[0][4]);
		Vector aug = new Vector(aug_matrix);
		return aug;
	}
	
	public static void main(String [] args) {
		LinearEq solver = new LinearEq(args[0]);
		solver.A().show("A");
		solver.b().show("b");
		solver.aug_matrix().show("Augmented Matrix");
//		
		solver.A().writeToFile(args[1]);
		solver.b().writeToFile(args[1], true);
	}
}

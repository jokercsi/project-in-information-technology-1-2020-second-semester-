package task11_3;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;



public class Matrix{
	private static final double EPSILON = 1e-10;
	private final double[][] all_matrix; // combined matrix
	
	public Matrix(String args){
		all_matrix = readFromFile(args);
	}
	
	// read txt file
	public double[][] readFromFile(String file){
		int rows = 0;
		int columns = 0;
		ArrayList<ArrayList<Double>> data = new ArrayList<ArrayList<Double>>();
		try { 
			Scanner input = new Scanner (new File(file));
			for(rows =0; input.hasNextLine(); rows++) {
				String nextLine = input.nextLine();
				if(nextLine.isEmpty()) {
					break;
				}
				else {		
					Scanner colReader = new Scanner(nextLine);
					ArrayList<Double> col = new ArrayList<Double>();
					for (columns = 0; colReader.hasNextDouble(); columns++) {
						col.add(colReader.nextDouble());
					}
					data.add(col);
					colReader.close();
				}
			}
			input.close();
		} catch (IOException e) {
			System.out.println(e);
		}
		//2 double[][]
		double a[][] = new double[rows][columns];
		try {
			Scanner input = new Scanner(new File(file));
			for(int i = 0; i < rows; ++i) {
				for(int j = 0; j < columns; ++j) {
					if(input.hasNextDouble()) {
						a[i][j] = input.nextDouble();
					}
				}
			}
			input.close();
		} catch (IOException e) {
			System.out.println(e);
			System.exit(1);
		}
		return(a);
	}
	
	
// recursive determinant
//	public double recurvie_det(double[][] matrix) {
//		double sum = 0.0;
//		int s;
//		int length = matrix.length; // rows = column.  because it is determinant
//	    if(length==1){
//	        return(matrix[0][0]);
//	    }
//		for(int i =0; i < length; i++ ) {
//			double[][] smaller = new double[length-1][length-1];
//			for(int j =1; j < length; j++ ) {
//				for(int k =0; k < length; k++ ) {
//					if(k<i) {
//						smaller[j-1][k] = matrix[j][k];
//					}
//					else if(k>i) {
//						smaller[j-1][k-1] = matrix[j][k];
//					}
//				}
//			}
//			if(i%2==0) {
//				s = 1;
//			}
//			else {
//				s = -1;
//			}
//			sum += s*matrix[0][i]*(Math.round(recurvie_det(smaller)/(100*EPSILON))*100*EPSILON);
//		}
//		return(sum);
//	}
	
	//Determinant method
	public double det() {
		//////////////////////////////////////////////////
		// using recursive method 
		//double determinant = recurvie_det(all_matrix);
		//return determinant;
		/////////////////////////////////////////////////

		
		
		double det,buf;
		int n = all_matrix.length;
		double[][] a = new double[n][n];
		for(int i = 0; i < n; i++) {
			for(int j =0; j < n; j++) {
				a[i][j] = all_matrix[i][j];
			}
		}
		
		// forword elimination
		int i,j,k;
		for(i=0; i<n; i++){
			for(j=0;j<n;j++){
				if(i<j){  // row < column = right side of matrix
					buf = a[j][i] / a[i][i]; // left side of matrix
					for(k=0;k<n;k++){
						
						a[j][k]-= a[i][k] * buf;
					}
				}
			} 
		}
		
		for(i=0;i<n;i++){
			if (Math.abs(a[i][i]) <= EPSILON) {
				throw new ArithmeticException("Matrix is singular or nearly singular");
			}
		}
		
		
		double diag = 1.0;
		double inv_diag = -1.0;
		// multiple 
		for(i=0;i<n;i++){
			diag *= a[i][i];
			for(j = n-1; 0<=j; j--) {
				inv_diag *= a[i][j];
			}
		}

		det = diag + inv_diag;
		/////////////////////////////////////////////////
		

	    return det; 
	}

	public void show() {
		int n = all_matrix.length;
		for(int i = 0; i <n; i++) {
			for(int j =0; j < n; j++) {
				System.out.printf(all_matrix[i][j] + " ");
			}
			System.out.printf("\n");
		}
	}
	
	public static void main(String[] args) {
		Matrix m = new Matrix(args[0]);
		double det = m.det();
		m.show();
		System.out.println("Det: " + det);
		
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(args[1]));
			writer.write(String.valueOf(det));
			writer.close();
		} catch(Exception e){
			e.printStackTrace();
		}
	}
}

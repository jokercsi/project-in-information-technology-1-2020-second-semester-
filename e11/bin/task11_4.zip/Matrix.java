package task11_4;

import java.io.*;
import java.util.*;

public class Matrix {
	private static final double EPSILON = 1e-10;
	
	double[][] matrix; 

	Matrix(String txtfile){
		matrix = readFromFile(txtfile);
	}
	
	//Determinant method
//	public double det() {
//		////////////////////////////////////////////////
//		//using recursive method 
//		double det = recurvie_det(matrix);
//		///////////////////////////////////////////////
//	    return det; 
//	}
	
	// recursive determinant
//	public double recurvie_det(double[][] matrix) {
//		double sum = 0.0;
//		int s;
//		int length = matrix.length; // rows = column.  because it is determinant
//	    if(length==1){
//	        return(matrix[0][0]);
//	    }
//		for(int i =0; i < length; i++ ) {
//			double[][] smaller = new double[length-1][length-1];
//			for(int j =1; j < length; j++ ) {
//				for(int k =0; k < length; k++ ) {
//					if(k<i) {
//						smaller[j-1][k] = matrix[j][k];
//					}
//					else if(k>i) {
//						smaller[j-1][k-1] = matrix[j][k];
//					}
//				}
//			}
//			if(i%2==0) {
//				s = 1;
//			}
//			else {
//				s = -1;
//			}
//			sum += s*matrix[0][i]*(recurvie_det(smaller));
//		}
//		return(sum);
//	}
	
	public double[][] readFromFile(String file){
		int rows = 0;
		int columns = 0;
		ArrayList<ArrayList<Double>> data = new ArrayList<ArrayList<Double>>();
		try { 
			Scanner input = new Scanner (new File(file));
			for(rows =0; input.hasNextLine(); rows++) {
				String nextLine = input.nextLine();
				if(nextLine.isEmpty()) {
					break;
				}
				else {		
					Scanner colReader = new Scanner(nextLine);
					ArrayList<Double> col = new ArrayList<Double>();
					for (columns = 0; colReader.hasNextDouble(); columns++) {
						col.add(colReader.nextDouble());
					}
					data.add(col);
					colReader.close();
				}
			}
			input.close();
		} catch (IOException e) {
			System.out.println(e);
		}
		
		//2 double[][]
		double a[][] = new double[rows][columns];
		try {
			Scanner input = new Scanner(new File(file));
			for(int i = 0; i < rows; ++i) {
				for(int j = 0; j < columns; ++j) {
					if(input.hasNextDouble()) {
						a[i][j] = input.nextDouble();
					}
				}
			}
			input.close();
		} catch (IOException e) {
			System.out.println(e);
			System.exit(1);
		}
		return(a);
	}
	
	public double [] inv() {
		int i, j, k, ip;
		double alpha, tmp;
		double amax;
		int n = matrix.length;
		
		int[] p = new int[n];
		for(k= 1; k <= n-1; k++) {
			amax = Math.abs(matrix[k][k]);
			ip = k;
			for( i = k+1; i <= n; i++) {
				if (Math.abs(matrix[k][k])  > amax ) {
					amax = Math.abs(matrix[i][k]); 
					ip = i;
				}
			}
			//check NxN//
			if (Math.abs(matrix[k][k]) <= EPSILON) {
				throw new ArithmeticException("Matrix is singular or nearly singular");
			}
			p[k] = i;
			if(ip != k) {
				for(j = k; j <= n; j ++) {
					tmp = matrix[k][j];
					matrix[k][j] = matrix[ip][j];
					matrix[ip][j] = tmp;
				}
			}
			
			//forword elimination
			for(i = k +1; i < n; i++) {
			      alpha = - matrix[i][k]/matrix[k][k];
			      matrix[i][k] = alpha;
			      for( j = k+1; j < n; j++)
			      {
			    	  matrix[i][j] = matrix[i][j] + alpha * matrix[k][j];
			      }
			}
            
		}
		
		
		double [] b = {-10.0, 60.0, 8.0, 6.0}; 
		
		for( k = 1; k <= n-1; k++){
			tmp=b[k];
			b[k]=b[p[k]];
			b[p[k]]=tmp;

		    for( i=k+1; i <= n; i++)
		    {
		      b[i] = b[i] + matrix[i][k]*b[k];
		    }
		    b[k] = tmp/matrix[k][k];
		  }
		
//		for(i = 0; i < n; i ++) {
//			for(j =0; j < n; j++) {
//				
//				System.out.println(tmp);
//			}
//		}

        return b;
	}

	
	public static void main(String[] args) {
		Matrix readMatix = new Matrix(args[0]); // initailize a Matrix A with the first commnad line
		//A inverse
		/*A.inv().show*/readMatix.inv(); // 1. calculate inverse matrix, 2. connect to Vector class
		
		
		//A inverse * A
		//Vector mul(readMatrix.inv(), readMatrix.A());
		
		//A * A inverse
		//Vector mul(readMatrix.A(), readMatrix.inv() )
		
	}
}

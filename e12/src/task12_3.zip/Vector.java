package task12_3;

public class Vector {

}
